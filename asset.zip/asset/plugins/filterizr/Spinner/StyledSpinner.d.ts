import StyledFilterizrElement from '../StyledFilterizrElement';
export default class StyledSpinner extends StyledFilterizrElement {
    initialize(): void;
    fadeOut(): Promise<void>;
}
