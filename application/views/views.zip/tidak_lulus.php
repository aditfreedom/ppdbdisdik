<div class="content-wrapper">
<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col">
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <div class="alert alert-danger" role="alert">
        Anda Tidak Berhak Untuk Mendaftar Ulang Karena Anda Telah Dinyatakan <b>Tidak Lulus!</b>
      </div>
  
    </section>
</div>
</div>
<br>