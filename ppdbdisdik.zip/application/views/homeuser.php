<div class="content-wrapper">
 <!-- Content Header (Page header) -->
 <div class="content-header">
 <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="container">
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <img src="<?=base_url()?>assets/img/dashboard.jpg" style="width:100%;height:50%;" srcset="" class="img-fluid mx-auto d-block" alt="Responsive image">
        <br>
        <a class="btn rounded-pill text-light" href="<?=base_url('user/isi_formulir/'.$id_pesertadidik)?>" style="width:100%;background-color:#FF0064;" role="button"><b>MENDAFTAR</b></a>     



       
        </div>
        
        
    </section>
    
    </div>
</div>
<!-- Button trigger modal -->



</div>

