<div class="content-wrapper">
<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col">
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <div class="alert alert-danger" role="alert">
        Anda Belum Dapat Cetak Kartu Dikarenakan Status Pendaftaran Formulir Belum Diapprove!
        <br> Silahkan Hubungi Admin Sekolah Untuk Approval</b>
      </div>
  
    </section>
</div>
</div>
<br>