# ppdbdisdik
