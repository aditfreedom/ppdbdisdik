<script type="text/javascript">
function jsFunction(){
alert('Gagal Mengirim Data!');
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
